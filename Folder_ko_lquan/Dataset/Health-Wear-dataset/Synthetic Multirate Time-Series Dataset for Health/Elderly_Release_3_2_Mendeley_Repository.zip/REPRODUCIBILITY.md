# Steps to reproduce Release 3.2

1. Extract Elderly_Release_3_2_Mendeley_Repository.zip into an empty directory. Keep the filenames unchanged.
2. Read README.md and data_dictionary.csv. Verify the archive using the separately supplied SHA-256 file and verify its payload against repository_checksums_sha256.csv.
3. Open Elderly_Release_3_2_Executed_Colab.ipynb in Google Colab. Its saved outputs document the supplied run. Use a fresh runtime for reproduction.
4. Inspect environment_versions.csv. Recreate the recorded versions where possible; the notebook installs missing packages rather than enforcing a complete environment lock. A different runtime can change numerical results and file hashes.
5. Obtain the original SisFall archive from the source linked at https://doi.org/10.3390/s17010198. Required size: 232407821 bytes. Required SHA-256: 7f0dd1583e39fee0f402a6855976eb12517f7eaecdacce871d5b3421793ad665. The notebook checks this exact archive. A repacked ZIP can fail the fingerprint despite containing similar files.
6. Run all notebook cells in order. Supply the verified SisFall ZIP when requested. The default generation route uses frozen calibration values and does not require the parent CSV. The notebook clears its designated generated-output directory before generation.
7. Check for 120 subjects, 960 events, 362240 samples, 960 event-feature rows, 576 internal predictions, 4505 SisFall recordings and 33823 SisFall windows. Review all audit outputs rather than only the final PASS message.
8. Download the notebook-generated bundle and save the newly executed notebook. The notebook produces 34 output files plus inventory and checksum sidecars; it does not regenerate the extra repository documentation in this 43-file deposit package.

The current repository packaging was checked without rerunning the full simulation or reprocessing the original SisFall archive. Source data are not redistributed.
