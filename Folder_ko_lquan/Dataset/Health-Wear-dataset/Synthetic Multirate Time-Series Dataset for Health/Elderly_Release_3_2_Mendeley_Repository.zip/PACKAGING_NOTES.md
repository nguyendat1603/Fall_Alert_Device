# Repository packaging notes

This package assembles the previously supplied 34 generated outputs and executed notebook without editing their bytes. It adds eight repository files: README.md, REPRODUCIBILITY.md, LICENSE.txt, CITATION.cff, PACKAGING_NOTES.md, PACKAGING_VALIDATION.json, repository_file_inventory.csv and repository_checksums_sha256.csv.

This packaging does not change the generator, simulation, predictions or execution history. The saved notebook produces a 34-output download bundle, not this documentation-enriched 43-file archive. The manuscript and standalone Figure 1 are not included in this dataset archive. Repository DOI and publication date are not invented. Use Mendeley's assigned citation when available.

Files offered separately alongside the ZIP are convenient copies of files already inside it. They do not increase the archive's count of 43.
